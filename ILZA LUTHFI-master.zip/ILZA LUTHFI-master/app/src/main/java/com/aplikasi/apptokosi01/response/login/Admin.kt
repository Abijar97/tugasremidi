package com.aplikasi.apptokosi01.response.login

data class Admin(
    val id:String,
    val email:String,
    val password:String,
    val nama:String
)
