package com.aplikasi.apptokosi01.response.produk

data class ProdukResponse(
    val data: Data,
    val message: String,
    val success: Boolean
)
